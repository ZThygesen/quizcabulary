from initialization import *

import game_functions as game

import draw_functions as draw

import sound_functions as sound

import credits_creator as credit


# draws the layout and instructions for how to play the game
def how_to_play():
    draw.draw_how_to_play()

    # await player's response to either quit the game or go back to main menu
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            # if player clicks, take mouse position of click
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos

                # quit game button pressed
                if quit_button.collidepoint(mouse_pos):
                    pygame.quit()
                    quit()

                # main menu button pressed
                if menu_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    main(1)


# initiates credit screen drawing
def show_credits():
    # creates blank canvas
    draw.draw_play_area()
    draw.draw_menu_button(menu_button, '#696969', menu_text, (width * 0.443, height * 0.895), menu_border)
    pygame.display.update()

    # calls credits_creator() and stays there until player quits or returns to main menu
    credit.credits_creator()
    main(1)


# controls the start of games
def main(stop_music = 0):
    # a special case where we dont want the music to restart each time we call main
    # (when coming from credits or how to play screens)
    if stop_music == 0:
        sound.start_menu_music()

    # variables that keep track of which main menu buttons have been selected
    game_mode_selected, num_players_selected, difficulty_selected = False, False, False
    game_mode, num_players, difficulty = 0, 0, 0

    # set up main menu
    draw.draw_play_area()
    draw.draw_main_menu()

    # waits for player to make decision
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            # if player clicks, take mouse position of click
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos

                # quit game button pressed
                if quit_button.collidepoint(mouse_pos):
                    pygame.quit()
                    quit()

                # credits button pressed
                if credits_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    show_credits()

                # how to play button pressed
                if how_to_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    how_to_play()

                # mode 1 or mode 2 button pressed
                if game_mode1_button.collidepoint(mouse_pos) or game_mode2_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    game_mode_selected = True

                    # shows which button is currently selcted by drawing a different colored border
                    if game_mode1_button.collidepoint(mouse_pos):
                        game_mode = 1
                    elif game_mode2_button.collidepoint(mouse_pos):
                        game_mode = 2
                    
                    draw.game_mode_selected(game_mode)

                # 1 player, 2 players, or time trial button pressed
                if single_player_button.collidepoint(mouse_pos) or multi_player_button.collidepoint(mouse_pos) or time_trial_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    num_players_selected = True

                    # shows which button is currently selcted by drawing a different colored border
                    if single_player_button.collidepoint(mouse_pos):
                        num_players = 1
                    elif multi_player_button.collidepoint(mouse_pos):
                        num_players = 2
                    else:
                        num_players = 3
                    
                    draw.num_players_selected(num_players)

                # easy, medium, or hard button pressed
                if easy_button.collidepoint(mouse_pos) or medium_button.collidepoint(mouse_pos) or hard_button.collidepoint(mouse_pos):
                    sound.button_sound()
                    difficulty_selected = True

                    # shows which button is currently selcted by drawing a different colored border
                    if easy_button.collidepoint(mouse_pos):
                        difficulty = 1
                    elif medium_button.collidepoint(mouse_pos):
                        difficulty = 2
                    else:
                        difficulty = 3

                    draw.difficulty_selected(difficulty)

                # if the 3 options needed are selected, start button can now be activated
                if game_mode_selected and num_players_selected and difficulty_selected:

                    # if start button pressed
                    if start_button.collidepoint(mouse_pos):
                        sound.button_sound()

                        game_mode_selected, num_players_selected, difficulty_selected = False, False, False 

                        # call start of backend
                        restart = game.game_mode_select(game_mode, num_players, difficulty)
                        if restart:
                            main()

        pygame.display.update()

main()

