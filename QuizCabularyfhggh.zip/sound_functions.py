import pygame

import random


# plays button sound
def button_sound():
    press = pygame.mixer.Sound('Sounds/button_press.ogg')
    pygame.mixer.Sound.play(press)


# plays a random song for the main menu
def start_menu_music():
    random_song = random.randrange(3)
    pygame.mixer.music.load('Sounds/{}'.format(menu_music[random_song]))
    pygame.mixer.music.play(-1)


# plays a random song for playing a game
def start_playing_music():
    random_song = random.randrange(7)
    pygame.mixer.music.load('Sounds/{}'.format(game_music[random_song]))
    pygame.mixer.music.play(-1)


# lists of the names of the music files
menu_music = ['menu_music1.ogg', 'menu_music2.ogg', 'menu_music3.ogg']
game_music = ['music1.ogg', 'music2.ogg', 'music3.ogg', 'music4.ogg', 'music5.ogg', 'music6.ogg', 'music7.ogg']

